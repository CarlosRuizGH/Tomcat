package ut.CPEN410;

public class CPEN410Class{
	
	private int Value;
	
	public CPEN410Class(int Val)
	{
		Value = Val;
	}
	public int getValue()
	{return Value;}
}
